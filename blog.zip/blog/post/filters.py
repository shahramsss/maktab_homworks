import django_filters
from .models import Post , Category


class PostFilter(django_filters.FilterSet):
    title_in = django_filters.CharFilter(field_name='title', lookup_expr='icontains')

    class Meta:
        model = Post
        fields = ['title']

class CategoryFilter(django_filters.FilterSet):
    category_in = django_filters.CharFilter(field_name='title', lookup_expr='icontains')

    class Meta:
        model = Category
        fields = ['title']
