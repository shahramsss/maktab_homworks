from django.db import models
from django.db.models import fields
from django.db.models.base import Model
from rest_framework import serializers
from .models import Post , Comment , Category
from django.contrib.auth.models import User




class Post_serializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ['title' , 'description', 'short_description' , 'slug','category']
        

        
class  Comment_serial(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'


class Category_serial(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class Post_detail(serializers.ModelSerializer):
    comments = Comment_serial(read_only=True, many=True ,source = 'commnet_post')
    category = Category_serial(read_only=True, many=True )
    class Meta:
        model = Post
        fields = "__all__"


class User_serial(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class Comment_serial_detial(serializers.ModelSerializer):
    author  = User_serial()
    post = Post_serializer()
    class Meta:
        model = Comment
        # fields = ["id","text","created_at"]
        fields = '__all__'