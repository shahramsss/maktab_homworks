from django.urls import path , include
from .views import *
urlpatterns = [
    path('posts/', posts ),
    path('detail/<int:post_id>', post_detail_by_id , name='detail'),
    path('detail/<str:post_slug>', post_detail_by_slug , name='detail'),
    path('categorys/', categorys , name='categorys'),
    path('category_details/<str:category_title>', category_details , name='category_details'),
    path('allposts/', PostListView.as_view() , name='allposts'),
    path('getpost/<slug:post_slug>', GetPost.as_view() , name='allposts'),
    # path('newslug/<slug:new_slug>', check_slug , name='check_slug'),
    path('postserial/', post_serial , name='post_serial'),
    path('postserialdetail/<int:post_id>', post_serial_detail , name='postserialdetail'),
    path('categoryserial/', category_serial , name='category_serial'),
    path('commentsserial/', comments_serial , name='comments_serial'),
    path('commentsserialdetail/<int:comment_id>', comments_serial_detail , name='comments_serial_detail'),
    path('postdetailsdrf/<int:pk>', PostDetailsDRF.as_view() , name='postdetailsdrf'),
    path('postlist/', PostList.as_view() , name='postlist'),
    path('mycategorylist/', CategoryList.as_view() , name='mycategorylist'),
    path('commentlist/<int:pk>/', CommentList.as_view() , name='commentlist'),
    path('categorylistx/<int:pk>/', CategoryListDetail.as_view() , name='categorylist'),
]
