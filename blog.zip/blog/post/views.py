from django.db import models
from django.db.models.aggregates import Count
from django.db.models.base import Model
from django.shortcuts import render
from django.http import HttpResponse
from .models import Category, Post, Comment
from rest_framework.decorators import api_view
from .serializers import Post_serializer, Post_detail, Category_serial, Comment_serial, Comment_serial_detial
from rest_framework.response import Response
from django.views.generic import TemplateView, ListView, DetailView
from rest_framework import generics, mixins
from .filters import CategoryFilter, PostFilter

# Create your views here.


def posts(request):
    posts = Post.objects.all()
    print(posts)

    # return HttpResponse("posts")
    return render(request, 'index.html', {'posts': list(posts)})


def post_detail_by_id(request, post_id):
    post = Post.objects.get(id=post_id)
    # post_category = post.category.all
    comment = Comment.objects.filter(post=post_id)
    post_category = list(Post.objects.filter(
        id=post_id).prefetch_related('category'))
    return render(request, 'detail.html', {'post': post, 'post_category': post_category, 'commnets': comment})


def post_detail_by_slug(request, post_slug):
    post = Post.objects.get(slug=post_slug)
    # post_category = post.category.all
    comment = Comment.objects.filter(post__title=post_slug)
    post_category = list(Post.objects.filter(
        slug=post_slug).prefetch_related('category'))
    return render(request, 'detail.html', {'post': post, 'post_category': post_category, 'commnets': comment})


def categorys(request):
    categorys = Category.objects.all()
    return render(request, 'categorys.html', {'categorys': categorys})


def category_details(request, category_title):
    #    posts = Post.objects.get(category=category_title)
    posts = Post.objects.filter(category__title=category_title)

    return render(request, 'category_details.html', {'posts': posts})


class PostListView(ListView):
    model = Post
    context_object_name = "posts"
    template_name = "post_list_view.html"


class GetPost(DetailView):
    model = Post
    context_object_name = "post"
    slug_field = "slug"
    slug_url_kwarg = "post_slug"
    template_name = "post_detail_view.html"


@api_view(["GET"])
def post_serial(request):
    posts = Post.objects.all()
    serializer = Post_serializer(posts, many=True)
    return Response(data=serializer.data, status=200)


@api_view(["GET"])
def post_serial_detail(req, post_id):
    posts = Post.objects.get(id=post_id)
    serializer = Post_detail(posts)
    return Response(data=serializer.data, status=200)


@api_view(["GET"])
def category_serial(req):
    category = Category.objects.all()
    serializer = Category_serial(category, many=True)
    return Response(data=serializer.data, status=200)


@api_view(["GET"])
def comments_serial(req):
    commnets = Comment.objects.all()
    serializer = Comment_serial(commnets, many=True)
    return Response(data=serializer.data, status=200)


@api_view(["GET"])
def comments_serial_detail(req, comment_id):
    commnet = Comment.objects.get(id=comment_id)
    serializer = Comment_serial_detial(commnet)
    return Response(data=serializer.data, status=200)


class PostDetailsDRF(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = Post_serializer

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class PostList(generics.ListAPIView):
    queryset = Post.objects.all()
    serializer_class = Post_serializer
    filterset_class = PostFilter

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)


class CategoryList(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = Category_serial
    filterset_class  = CategoryFilter

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)


class CommentList(generics.RetrieveUpdateDestroyAPIView):
    queryset = Comment.objects.all()
    serializer_class = Comment_serial

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class CategoryListDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Category.objects.all()
    serializer_class = Category_serial

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)
