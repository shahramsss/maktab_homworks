from django.test import TestCase
from rest_framework.test import APITestCase
from django.urls import reverse
from model_mommy import mommy
from .models import Post, Category, Comment


class TestPost(APITestCase):
    def setUp(self):
        mommy.make(Post)

    def test_post_list(self):

        url = reverse('post_serial')
        resp = self.client.get(path=url)
        self.assertEqual(resp.status_code, 200)


class TestCategory(APITestCase):
    def setUp(self):
        mommy.make(Category)

    def test_post_list(self):

        url = reverse('category_serial')
        resp = self.client.get(path=url)
        self.assertEqual(resp.status_code, 200)


class TestComment(APITestCase):
    def setUp(self):
        mommy.make(Comment)

    def test_post_list(self):

        url = reverse('comments_serial')
        resp = self.client.get(path=url)
        self.assertEqual(resp.status_code, 200)
