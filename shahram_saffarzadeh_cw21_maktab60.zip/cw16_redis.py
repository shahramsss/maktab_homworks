import redis

# redis_client = redis.Redis()
redis_client = redis.StrictRedis(decode_responses=True)


class Student:

    def __init__(self, name, age) -> None:
        student_number = redis_client.get('student_number')
        redis_client.incr('student_number')

        self.student_number = student_number
        self.name = name
        self.age = age

    def save(self):
        redis_client.hmset(
            f'student:{self.student_number}:info',
            {
                "name": self.name,
                "age": self.age,
                "student_number": self.student_number
            }
        )

    def add_grade(self, grade):
        redis_client.rpush(f"grade:{self.student_number}", grade)

    def get_gpa(self):
        # for item in redis_client.get(f"grade:{self.student_number}").decode("")
        list_gpa = redis_client.lrange(f"grade:{self.student_number}", 0, -1)
        result = 0
        for item in list_gpa:
            result += int(item)
        return result / len(list_gpa)

    def add_course(self, course_id):  ##
        course_value = redis_client.hget(f'course:{course_id}:info', 'name')
        redis_client.rpush(f"{self.student_number}:courses", course_value)

    @classmethod
    def get_all_students(cls):
        all_list = redis_client.keys('student:*')
        all_student = []
        for item in all_list:
            all_student.append(redis_client.hgetall(item))
        return all_student


class Course:
    def __init__(self, name, term):
        course_number = redis_client.get('course_number')
        redis_client.incr('course_number')
        self.id = course_number
        self.name = name
        self.term = term

    def save(self):
        # add course info model
        # add to term list
        redis_client.hmset(
            f'course:{self.id}:info',
            {
                "name": self.name,
                "term": self.term,
                "course_id": self.id
            }
        )

        redis_client.rpush(
            f'term:{self.term}', self.id  # id = course
        )

    @classmethod
    def get_all_courses(cls):
        all_list = redis_client.keys('course:*')
        all_course = []
        for item in all_list:
            all_course.append(redis_client.hgetall(item))
        return all_course

    @classmethod
    def get_all_courses_by_term(cls, term):
        all_list = redis_client.lrange(f'term:{term}', 0, -1)
        all_term = []
        for item in all_list:
            all_term.append(item)
        return all_term
