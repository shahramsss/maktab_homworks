import unittest
import redis

from cw16_redis import Student , Course


class TestStudentMethods(unittest.TestCase):

    def setUp(self):
        self.redis_client = redis.Redis()

    def test_save(self):
        student = Student('Ali', 20)
        student.save()

        student_from_redis = self.redis_client.hmget(
            f'student:{student.student_number}:info',
            'name'
        )

        print(student_from_redis)

        self.assertIsNotNone(student_from_redis)
        self.assertEqual(student_from_redis[0].decode('utf-8'), student.name)

    def test_student_number_incr(self):
        student_number = self.redis_client.get('student_number')

        student = Student('Ali', 20)
        student.save()

        student = Student('Mohammad', 25)
        student.save()

        new_student_number = self.redis_client.get('student_number')

        self.assertEqual(int(new_student_number), int(student_number) + 2)

    def test_Student_gpa(self):
        student = Student('Ali', 20)
        student.save()
        student.add_grade(20)
        student.add_grade(40)
        self.assertEqual(student.get_gpa(), 30)

    def test_get_all_students(self):
        student1 = Student('Ali', 20)
        student1.save()
        student2 = Student('Reza', 30)
        student2.save()
        # all_students = self.redis_client.hgetall('student:*')
        val1 = {'name': 'Reza', 'age': '30', 'student_number': '2'}
        val2 = {'name': 'Ali', 'age': '20', 'student_number': '5'}
        self.assertIn(val1, Student.get_all_students())
        self.assertIn(val2, Student.get_all_students())
        # print(Student.get_all_students())

    def test_add_course(self):
        student = Student('Ali', 20)
        student.save()
        student.add_course(100)


class TestCourse(unittest.TestCase):
    def setUp(self):
        # self.redis_client = redis.Redis()
        self.redis_client = redis.StrictRedis(decode_responses=True)

    def test_save_course(self):
        course = Course('zaban', 5)
        course.save()

        course_from_redis = self.redis_client.hmget(
            f'course:{course.id}:info',
            "name"
        )
        print(course_from_redis)

        self.assertIsNotNone(course_from_redis)
        self.assertEqual(course_from_redis[0], course.name)
        # print(self.redis_client.lrange('term:5', 0, -1))


    def test_get_all_course(self):
        course = Course('zaban', 5)
        course.save()
        course = Course('ryazi', 5)
        course.save()
        val1 = {'name': 'ryazi', 'term': '5', 'course_id': '107'}
        val2 = {'name': 'zaban', 'term': '5', 'course_id': '106'}
        self.assertIn(val1, Course.get_all_courses())
        self.assertIn(val2, Course.get_all_courses())
        # print(Course.get_all_courses())

    def test_get_course_by_term(self):
        course1 = Course('zaban', 5)
        course1.save()
        course2 = Course('hendese', 8)
        course2.save()
        self.assertIn(course1.id, Course.get_all_courses_by_term(5))
        self.assertIn(course2.id, Course.get_all_courses_by_term(8))
        # print(Course.get_all_courses_by_term(5))




