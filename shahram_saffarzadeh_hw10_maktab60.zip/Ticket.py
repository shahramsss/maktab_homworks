import datetime
import redis


class Person:
    admin_discount_code = "admin"
    student_discount_code = "student"
    employee_discount_code = "employee"
    customer_discount_code = "customer"
    admin_discount = 100
    student_discount = 200
    employee_discount = 300
    customer_discount = 400
    username = ""

    user_type = ""
    logged_in = False
    redis_client = redis.Redis(charset="UTF-8", decode_responses=True)

    def login(self, username, password):
        self.username = username
        if self.redis_client.hget(username, password):
            self.user_type = self.redis_client.hget(username, password)
            print(f"Hi {username} ")
            self.logged_in = True
            print("Events : ")
            events = (self.redis_client.keys("events*"))
            for i in events:
                print(self.redis_client.hgetall(i))
            self.redis_client.hmset("logs", {"log in time": str(datetime.datetime.now()), "login ": username})
        else:
            print("your user name or password is not valid")

    def sign_in(self, username, password, user_type):

        if self.redis_client.exists(username):
            print("this username is used")
        else:
            self.redis_client.hset(username, str(password), user_type)
            self.redis_client.hmset("logs", {"sign in time": str(datetime.datetime.now()), "sign in ": username})

    def buy_ticket(self, event_title, number_ticket, discount_code):
        discount = 0
        flag = False
        if self.logged_in:
            print(f"customer : {self.username} ")
            events = (self.redis_client.keys("events*"))
            for i in events:
                if self.redis_client.hgetall(i)["title"] == event_title:
                    event = self.redis_client.hgetall(i)
                    flag = True
                    reaming = int(event["total_capacity"]) - (int(event["reserved_capacity"]) + number_ticket)
                    if event["discount_code"] == self.admin_discount_code:
                        discount = self.admin_discount
                    if event["discount_code"] == self.student_discount_code:
                        discount = self.student_discount
                    if event["discount_code"] == self.customer_discount_code:
                        discount = self.customer_discount
                    if event["discount_code"] == self.employee_discount_code:
                        discount = self.employee_discount
                    str_event = {"title": event["title"],
                                 "location": event["location"],
                                 "time": event["time"],
                                 "total_capacity": event["total_capacity"],
                                 "reserved_capacity": int(event["reserved_capacity"]) + number_ticket,
                                 "reaming_capacity": reaming,
                                 "ticket_price": int(event["ticket_price"])}
                    self.redis_client.hmset("events:" + event["title"], str_event)
                    self.redis_client.hmset("logs",
                                            {"event_time": str(datetime.datetime.now()), "buy ticket": event["title"]})
                    print(self.redis_client.hgetall(i))
                    print(
                        f"discount is : {discount}$  and payment is :{int(self.redis_client.hgetall(i)['ticket_price']) - discount}")
                    break
        if not flag:
            print("this events name is not in events")


class Event:
    admin_discount_code = "admin"
    student_discount_code = "student"
    employee_discount_code = "employee"
    customer_discount_code = "customer"
    reserved_capacity = 0
    redis_client = redis.Redis(charset="UTF-8", decode_responses=True)

    # redis_client = redis.StrictRedis(decode_responses=True)

    def __init__(self, name, year, month, day, hour, minute, location, total_capacity, ticket_price):
        self.name = name
        self.event_time = datetime.datetime(year=year, month=month, day=day, hour=hour, minute=minute)
        self.location = location
        self.total_capacity = total_capacity
        self.ticket_price = ticket_price
        if (total_capacity - self.reserved_capacity) <= 0:
            print("capacity is full")
        else:
            str_event = {"title": self.name,
                         "location": self.location,
                         "time": str(self.event_time),
                         "total_capacity": self.total_capacity,
                         "reserved_capacity": self.reserved_capacity,
                         "reaming_capacity": self.total_capacity - self.reserved_capacity,
                         "ticket_price": self.ticket_price,
                         "discount_code": self.admin_discount_code}
            self.redis_client.hmset("events:" + self.name, str_event)


class Logs:
    redis_client = redis.Redis(charset="UTF-8", decode_responses=True)

    def print_logs(self):
        logs = self.redis_client.hgetall("logs")
        keys = list(logs.keys())
        values = list(logs.values())
        print("logs : ")
        for i in range(len(logs)):
            print(keys[i], values[i])

e1 = Event("theaters1", 2021, 5, 12, 20, 30, "tehran", 500, 1000)
e2 = Event("theaters2", 2020, 5, 12, 20, 30, "tehran", 500, 2000)
e3 = Event("theaters3", 2019, 5, 12, 20, 30, "tehran", 500, 2000)

p = Person()
p.sign_in("sss", 111, "admin")
p.login("sss", 111)
p.buy_ticket("theaters1", 5, "admin")
# p.buy_ticket("theaters1", 5, "admin")
# p.buy_ticket("theaters1", 5, "admin")
# p.buy_ticket("theaters1", 30, "admin")
# p.buy_ticket("theaters1", 30, "admin")
p1 = Person()
p1.sign_in("sss1", 111, "student")
p1.login("sss1", 111)
p1.buy_ticket("theaters1", 30, "admin")
l = Logs()
l.print_logs()
